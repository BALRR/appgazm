package com.example.appyjumpdemo;


import com.appyjump.sdk.AppyjumpAds;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
	
	AppyjumpAds appyjumpAds;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);	
		
		appyjumpAds=new AppyjumpAds(MainActivity.this, "63eb7fd2278cf741114ce28f68ab1805", AppyjumpAds.INTERSTITIAL);
		appyjumpAds.show();
	}
	
	
	@Override
	protected void onPause() {
		super.onPause();
		appyjumpAds.pause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		appyjumpAds.resume();
	}
}
